importScripts('https://sauce-demo.myshopify.com/cdn/wpm/s704e843dw38e170ffp88ffc213ma0cfcc05m.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('shopify-app-pixel', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-shopify-app-pixel@0520.js');
